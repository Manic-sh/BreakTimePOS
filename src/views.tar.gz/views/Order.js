import React from 'react';
import {withRouter} from 'react-router-dom';

import ProductGrid from '../components/MenuCard.js';
import SideBar from '../components/SideBar.js'
import {fetchData, postQtyChange, addOrEditProduct, lookupOptionsPUT} from '../helpers/fetchdata.js';
import {KOT_DETAIL_ENDPOINT, ORDER_ITEMS_ENDPOINT, ORDER_ENDPOINT} from '../helpers/endpoints.js';

import { Layout, Spin } from 'antd';

const {Content, Sider} = Layout;

class Order extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            selected_categories: [],
            order_data: '',
            order_items:[],
            order_id: '',
            doneLoading: false
        }
    }

    getOrderItems(id){
        const endpoint = ORDER_ITEMS_ENDPOINT + '?order_related=' + id;
        const thisComp = this;
        fetchData(endpoint, thisComp, 'order_items', true)
    }

    getOrder(id){
        const endpoint = ORDER_ENDPOINT + id + '/';
        const thisComp = this;
        fetchData(endpoint, thisComp, 'order_data', false);
    }

    changeQty = (action, item_id) => {
        postQtyChange(action, item_id, this);
    };

    handleAddOrEditProduct = (menu_id) => {
        addOrEditProduct(this.state.order_data.id, menu_id, this);
    };

    handleProductActions = (action) => {
        const thisComp = this;
        const order = this.state.order_data;
        let data = {
            id: order.id,
            title: order.title,
            kot: order.kot,
            active: false,
        };

        let kotUpdate = { 
            active: false,
        }
        const kot_endpoint = KOT_DETAIL_ENDPOINT + order.kot + '/';
        const endpoint = ORDER_ENDPOINT + order.id + '/';
        switch (action){
            case 'CLOSE':
                fetch(endpoint, lookupOptionsPUT(data))
                .then(resp => resp.json())
                .then(repsData => {
                    thisComp.props.history.push('/homepage')
                })
                break;
            case 'PRINT':
                fetch(endpoint, lookupOptionsPUT(data))
                .then(resp => resp.json())
                .then(
                    function(repsData) {
                        fetch(kot_endpoint, lookupOptionsPUT(kotUpdate)).then(res => {
                            thisComp.props.history.push('/homepage')
                    })    
                })
                break;    
            default:
                thisComp.props.history.push('/homepage')
        }
    };

    componentDidMount(){
        const {id} = this.props.match.params;
        this.getOrder(id) ;
        this.getOrderItems(id);
    }

    render() {
        const doneLoading = this.state.doneLoading;
        return(
            <div>
                {this.state.doneLoading ?
                <Layout>
                   <Content>
                        {doneLoading ? 
                        <ProductGrid
                            handleSelectedCategories={this.handleSelectedCategories}
                            handleAddOrEditProduct={this.handleAddOrEditProduct}
                        ></ProductGrid>
                        : 'Loding..'
                        }
                    </Content>
                    <Sider width={600} className="site-layout-background">
                        {doneLoading ?
                                    <SideBar
                                        order_data={this.state.order_data}
                                        order_items={this.state.order_items}
                                        handleProductActions={this.handleProductActions}
                                        handleAddOrEditProduct={this.handleAddOrEditProduct}
                                        changeQty={this.changeQty}
                                    />
                                    :  <p>Loding.. </p>
                                }
                    </Sider>
                </Layout>
                :   <div className="spinner">
                        <Spin />
                    </div>
                }
            </div>
        )
    }

}
export default withRouter(Order);