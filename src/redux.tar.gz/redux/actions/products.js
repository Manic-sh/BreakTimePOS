import {
    RETRIEVE_PRODUCTS,
    UPDATE_PRODUCTS,
    CREATE_ORDER,
    CREATE_ORDERITEM,
    RETRIEVE_ORDERS
  } from "./types";

import ProductDataService from "../services/products.services";


export const retrieveProducts = () => async (dispatch) => {
    try {
      const res = await ProductDataService.getAll();
  
      dispatch({
        type: RETRIEVE_PRODUCTS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
};

export const findProductByTitle = (title) => async (dispatch) => {
    try {
      const res = await ProductDataService.findByTitle(title);
  
      dispatch({
        type: RETRIEVE_PRODUCTS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
};