import http from "../http-common";

class ProductDataService {
  getAll() {
    return http.get("/menu-list");
  }

  get(id) {
    return http.get(`/menu-detail/${id}`);
  }

  findByTitle(title) {
    return http.get(`/menu-detail?title=${title}`);
  }
}

export default new ProductDataService();
