import React from 'react';
import PropTypes from 'prop-types'
import { List, Card, Button, Space, Descriptions, Modal, Divider } from 'antd';
import SearchFilterAdd from '../components/SearchFilterAdd.js';
import { PlusOutlined, MinusOutlined, DeleteOutlined } from '@ant-design/icons';

import ReactToPrint from 'react-to-print';

import InfiniteScroll from 'react-infinite-scroller';

const ButtonGroup = Button.Group;

export default class SideBar extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            modalPrintKot: false,
            modalPrintBill: false,
            loading: false,
        }
    }
    
    static propTypes = {
        handleProductActions: PropTypes.func,
        handleAddOrEditProduct: PropTypes.func,
        handleBack: PropTypes.func,
        order_items: PropTypes.array,
        order_data: PropTypes.object,
        changeQty: PropTypes.func.isRequired
    };

    handleCloseKOT = () => {
        this.props.handleProductActions('CLOSE')
    };
    handleCloseBill = () => {
        this.props.handleProductActions('PRINT')
    };

    handleBack = () => {
        this.props.handleProductActions('BACK')
    };

    changeQty = (action, item_id) => {
        this.props.changeQty(action, item_id)
    }

    handleAddOrEditProduct = (menu_id) => {
        this.props.handleAddOrEditProduct(menu_id)
    }
    handleInfiniteOnLoad = () => {
        this.setState({
            loading: true,
          });
    };
    setmodalPrintKot(modalPrintKot) {
        this.setState({ modalPrintKot });
    }
    
    setmodalPrintBill(modalPrintBill) {
        this.setState({ modalPrintBill });
    }
    

    render() {
        const { order_items } = this.props;
        const { order_data} = this.props;
        return (
            <div>
                <Card> 
                    <Card>
                        <h4 className='header'>
                            <SearchFilterAdd 
                                handleAddOrEditProduct={this.handleAddOrEditProduct}
                                changeQty={this.changeQty}
                            /> 
                        </h4>
                    </Card>
                    <div className="item-infinite-container">
                        <InfiniteScroll
                            initialLoad={false}
                            pageStart={0}
                            loadMore={this.handleInfiniteOnLoad}
                            useWindow={false}
                        >    
                            <List
                                dataSource={order_items}
                                    renderItem={item => (  
                                        <OrderItem 
                                            item={item} 
                                            changeQty={this.changeQty}
                                        />
                                    )}
                            >
                            </List>
                        </InfiniteScroll>      
                    </div>  
                    <Card className="item-total-info">
                        <Descriptions size="small" bordered>
                            <Descriptions.Item label="KOT">{order_data.tag_kot}</Descriptions.Item>
                            <Descriptions.Item label="Total">{order_data.tag_value}</Descriptions.Item>
                        </Descriptions>    
                    </Card>   
                    <Card>
                        <Space size={[10, 8]} wrap>
                            <Button  style = {{width: 220}} type="primary" onClick={() => this.setmodalPrintKot(true)}>Print KOT</Button>
                            <Modal
                                title="Order Details"
                                centered
                                visible={this.state.modalPrintKot}
                                onOk={() =>  this.handleCloseKOT()}
                                onCancel={() => this.setmodalPrintKot(false)}
                                footer={[
                                    <Button key="back" onClick={() => this.setmodalPrintKot(false)}>
                                        Cancel
                                    </Button>,
                                  <Button key="submit" type="primary"  onClick={() =>  this.handleCloseKOT()}>
                                        Ok
                                  </Button>,
                                        <ReactToPrint
                                        trigger={() => (
                                        <a className="ant-btn ant-btn-primary" href="#print-kot-bill">
                                            Print
                                        </a>
                                        )}
                                        content={() => this.componentRef}
                                    />,
                                ]}
                                >

                            <div ref={el => (this.componentRef = el)} > 
                                <div className="print-kot-bill">
                                    <Divider>BreakTime IN</Divider>
                                    <h4>Bill Number: {order_data.id} </h4>
                                    <h4>Order Number: {order_data.title} </h4> 
                                    <h4>Date: {order_data.tag_timestamp} </h4>
                                    <h4>Kot Number: {order_data.tag_kot}</h4>
                                    <hr />
                                    <p>
                                        Items
                                    </p>
                                    <hr />
                                        <List
                                            dataSource={order_items}
                                            renderItem={item => (  
                                                <PrintKOT 
                                                    item={item} 
                                                />
                                            )}
                                        /> 
                                    <hr />
                                     <ul className="total-ul">
                                         <li>Total Amount: </li>
                                         <li className="total-li">{order_data.tag_value}<span> INR</span></li>
                                     </ul>               
                                </div>
                            </div>
                            </Modal> 
                            <Button  style = {{width: 130}} type="primary"  onClick={() => this.setmodalPrintBill(true)}>Print Bill</Button>
                            <Modal
                                title="Order Details"
                                centered
                                visible={this.state.modalPrintBill}
                                onOk={() =>  this.handleCloseBill()}
                                onCancel={() => this.setmodalPrintBill(false)}
                                >
                                <Descriptions size="small" bordered>
                                    <Descriptions.Item label="Bill No">{order_data.id}</Descriptions.Item>
                                    <Descriptions.Item label="Order No">{order_data.title}</Descriptions.Item>
                                    <Descriptions.Item label="Date">{order_data.tag_timestamp}</Descriptions.Item>
                                </Descriptions>
                                <Card>           
                                    <List
                                        dataSource={order_items}
                                        renderItem={item => (  
                                            <PrintKOT 
                                                item={item} 
                                            />
                                        )}
                                    />
                                </Card> 
                                <Descriptions size="small" bordered>
                                            <Descriptions.Item label="KOT No">{order_data.tag_kot}</Descriptions.Item>
                                            <Descriptions.Item label="Total">{order_data.tag_value}</Descriptions.Item>     
                                </Descriptions>
               
                            </Modal> 
                            <Button  style = {{width: 130}} type="primary"  onClick={this.handleBack} danger>Back </Button>
                        </Space>  
                    </Card>
                </Card> 
            </div>
        )
    }
}

class OrderItem extends React.Component {

    static propTypes = {
        changeQty: PropTypes.func.isRequired,
        item: PropTypes.object.isRequired
    }

    addQty = () => {
       this.props.changeQty('ADD', this.props.item.id)
    };

    removeQty = () => {
        this.props.changeQty('REMOVE', this.props.item.id)
    };

    handleDeleteItem = () => {
        this.props.changeQty('DELETE', this.props.item.id)
    };


    render(){
        const item = this.props.item;
        return (

                <List.Item 
                    key={item.id}
                    actions={[                        
                        <ButtonGroup>
                            <Button onClick={this.addQty}>
                                <PlusOutlined />
                            </Button>
                            <Button onClick={this.removeQty}>
                                <MinusOutlined />
                            </Button>
                            <Button danager onClick={this.handleDeleteItem}>
                                <DeleteOutlined />
                            </Button>
                        </ButtonGroup>
                    ]}    
                >
                    <List.Item.Meta
                        title={item.tag_menu_related}
                        description={item.tag_total_value} 
                    />

                    <div>
                        {item.qty}
                        <span> x </span>
                        {item.tag_value}

                    </div>
                </List.Item>
        )
    }

}

class PrintKOT extends React.Component {

    static propTypes = {
        item: PropTypes.object.isRequired
    }
    render(){
        const item = this.props.item;
        return (

                <List.Item 
                    key={item.id} 
                >
                    <List.Item.Meta
                        title={item.tag_menu_related}
                    />
                    <div>
                        {item.qty}
                        <span> x </span>
                        {item.tag_value}
                        <span>      = </span>
                        {item.tag_total_value} 

                    </div>
                </List.Item>
        )
    }
}