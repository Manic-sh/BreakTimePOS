import React from 'react';
import {Link, Redirect} from 'react-router-dom';
import PropTypes from 'prop-types';
import { Layout, Menu, Image, Dropdown, Space, message } from 'antd';
import { UserOutlined, FireOutlined, FieldTimeOutlined, ShoppingOutlined } from '@ant-design/icons';
import AuthService  from "../helpers/axios-services/auth-service";

import Logo from '/home/mojo/pos_breaktime/frontend/src/logo.jpg';

const {  Header } = Layout;

export default class MyNavbar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            current: 'takeout',       
        };
    }
    static propTypes = {
        currentUser: PropTypes.string.isRequired
    };
  
    handleClick = e => {
            console.log('click ', e);
            this.setState({ current: e.key });
    };    
    handleButtonClick(e) {
            message.info('Click on left button.');
            console.log('click left button', e);
    };
          
    render() {
        const menu = (
            <Menu>
                <Menu.Item key="1">
                    <Link to={{
                            pathname: `/homepage/`
                        }}>Home Page
                    </Link>
                </Menu.Item>
                <Menu.Item key="2">
                    <Link to={{
                            pathname: `/reports/`
                        }}> Reports
                    </Link>
                </Menu.Item>
                <Menu.Item key="3">
                    <Link to={{
                            pathname: `/logout/`
                        }}> Logout
                    </Link>
                </Menu.Item>
            </Menu>
        );
        const { current } = this.state;
        const { currentUser } = this.props;
        console.log("User:   " + currentUser);
        return (
            <Header className="header">
                <div className="logo">
                    <Image src={ Logo } height={64} width={124} />
                </div>    
                    
                <Menu theme="dark" onClick={this.handleClick} selectedKeys={[current]} mode="horizontal">
                  <Menu.Item key="takeout" icon={<ShoppingOutlined />}>
                      Take Out
                  </Menu.Item>
                  <Menu.Item key="delivery" icon={<FireOutlined />}>
                    Delivery
                  </Menu.Item>
                  <Menu.Item key="swiggy"  icon={<FieldTimeOutlined />}>
                    Swiggy
                  </Menu.Item>
                </Menu>
                <div className="user-account">
                  <Space wrap> 
                    <Dropdown.Button overlay={menu} placement="bottomCenter" icon={<UserOutlined />}>

                    </Dropdown.Button>
                  </Space>  
                </div>
            </Header>
        );
    }
}
