import React from 'react';
import PropTypes from 'prop-types';

import { Select, Input, Form,  Space, InputNumber, Button } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import {MENU_ENDPOINT} from "../helpers/endpoints";
import {fetchData} from "../helpers/fetchdata";

const { Option } = Select;

export default class SearchFilterAdd extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            products: [],
            value: undefined,
            qty: '',
            doneLoading: false,
        };
    }

    static propTypes = {
        handleAddOrEditProduct: PropTypes.func,
        changeQty: PropTypes.func.isRequired
    };

    getProducts(endpoint){
        const thisComp = this;
        fetchData(endpoint, thisComp, 'products')
    };

    search = async val => {
        const thisComp = this;
        thisComp.setState({ loading: true });
        fetchData(MENU_ENDPOINT, thisComp, 'products')
        const products = thisComp.products;
    
        this.setState({ products, loading: false });
      };

    handleSearch = value => {
        if (value) {
            fetch(value, products => this.setState({ products }));
          } else {
            this.setState({ products: [] });
        }
    };
    
    handleChange = value => {
       console.log( this.setState({ value }));
    };
    
    handleChangeQty = qty =>  {
        this.setState({ qty });
    };

    handleProduct= () => {
        
        console.log('Menu ID');
        this.props.handleAddOrEditProduct(this.value);
    };
    componentDidMount(){
        const endpoint = MENU_ENDPOINT;
        this.getProducts(endpoint);
    };
    render() {
        const options = this.state.products.map(d => <Option key={d.id}><Space><span>{d.title}</span><span>{d.tag_value}</span></Space></Option>);
        
        return (   
            <Space direction="horizontal">
                <Select
                    showSearch
                    placeholder="Search Menu..."
                    style={{width: 310}}
                    filterOption={false}
                    onSearch={this.handleSearch}
                    onChange={this.handleChange}
                    notFoundContent={null}
                >
                    {options}
                </Select>
                <InputNumber min={1} max={99} defaultValue="1" onChange={this.handleChangeQty} />
                <Button type="primary" icon={<PlusOutlined />} onClick={this.handleProduct} >
                    Add
                </Button>
            </Space>
        );
    }
}    

