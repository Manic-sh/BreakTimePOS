import React, { Component } from "react";
import { Redirect } from 'react-router-dom';

import { Row, Col, Card, Form, Input, Button, Avatar } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import AuthService  from "../helpers/axios-services/auth-service";

const required = (value) => {
  if (!value) {
    return (
      <div className="alert alert-danger" role="alert">
        This field is required!
      </div>
    );
  }
};

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.handleLogin = this.handleLogin.bind(this);
    this.onChangeUsername = this.onChangeUsername.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);
    this.state = {
      username: "",
      password: "",
      loading: false,
      message: ""
    };
    
  }

  onChangeUsername(e) {
    this.setState({
      username: e.target.value,
    });
  }

  onChangePassword(e) {
    this.setState({
      password: e.target.value,
    });
  }

  handleLogin = (values) => {
    this.setState({
        message: "",
        loading: true,
    });

    console.log(values)
    if (values) {
        AuthService.login(this.state.username, this.state.password).then(
            () => {
              this.props.history.push("/homepage");
              window.location.reload();
            },
            error => {
              const resMessage =
                (error.response &&
                  error.response.data &&
                  error.response.data.message) ||
                error.message ||
                error.toString();
    
              this.setState({
                loading: false,
                message: resMessage
              });
            }
          );
        } else {
          this.setState({
            loading: false
          });
        }
    }  

  render() {
    return (
      <Row>
        <Col span={12} offset={6}>
          <Card className="login-form-card">  
              <Avatar
                size={{ xs: 24, sm: 32, md: 40, lg: 100, xl: 80, xxl: 100 }}
                icon={<UserOutlined />}
              />
              <Form
                name="normal_login"
                className="login-form"
                ref={(c) => {
                  this.form = c;
                }}
                onFinish={this.handleLogin}
              >
                <Form.Item
                  name="username"
                  rules={[
                    {
                      required: true,
                      message: 'Please input your Username!',
                    },
                  ]}
                >
                  <Input 
                    prefix={<UserOutlined className="site-form-item-icon" />} 
                    placeholder="Username"
                    name="username"
                    value={this.state.username}
                    onChange={this.onChangeUsername}
                    validations={[required]} 
                  />
                </Form.Item>
                <Form.Item
                  name="password"
                  rules={[
                    {
                      required: true,
                      message: 'Please input your Password!',
                    },
                  ]}
                >
                  <Input.Password
                    prefix={<LockOutlined className="site-form-item-icon" />}
                    type="password"
                    placeholder="Password"
                    name="password"
                    value={this.state.password}
                    onChange={this.onChangePassword}
                    validations={[required]}
                  />
                  
                </Form.Item>
                <Form.Item>
                  <Button type="primary" htmlType="submit" className="login-form-button">
                    Log in
                  </Button>
                  Or <a href="">register now!</a>
                </Form.Item>
              </Form>
          </Card>   
        </Col>
      </Row>
    );
  }
}
